#!/usr/bin/env python3

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date
from typing import Any


@dataclass
class SourceProgram:

    source: str

    channel_name: str

    title: str

    start: Any

    stop: Any | None = None

    description: str = ""

    category: str = ""

    confidence: float = 1.0


class EPGSource(ABC):

    name: str = ""

    priority: int = 999

    @abstractmethod
    async def fetch(
        self,
        page,
        channel,
        day: date,
    ) -> list[SourceProgram]:

        raise NotImplementedError

    def aliases_for(
        self,
        channel,
    ) -> list[str]:

        sources = getattr(
            channel,
            "epg_sources",
            {},
        )

        values = sources.get(
            self.name,
            [],
        )

        if not isinstance(
            values,
            list,
        ):

            return []

        return [
            str(value).strip()
            for value in values
            if str(value).strip()
        ]