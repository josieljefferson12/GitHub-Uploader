#!/usr/bin/env python3

from __future__ import annotations

import re
from datetime import datetime, timedelta

from bs4 import BeautifulSoup

from .base import EPGSource, SourceProgram


class GuiaDeTVSource(EPGSource):
    name = "guiadetv"
    priority = 3

    BASE_URL = "https://www.guiadetv.com/programacao"

    async def fetch(self, page, channel, day):
        aliases = self.aliases_for(channel)
        if not aliases:
            return []

        programs = []
        for slug in aliases:
            slug = str(slug).strip()
            if not slug:
                continue

            # URL: /programacao/{slug}/{data}  (ex: /globo/2026-08-09)
            date_str = day.isoformat()
            url = f"{self.BASE_URL}/{slug}/{date_str}"

            try:
                response = await page.goto(url, wait_until="domcontentloaded",
                                           timeout=channel.page_timeout)
            except Exception:
                continue

            if not response or response.status >= 400:
                continue

            try:
                await page.wait_for_load_state("networkidle", timeout=10000)
            except Exception:
                pass
            await page.wait_for_timeout(channel.wait_after_load)

            content = await page.content()
            parsed = self.parse_html(content, channel, day)
            if parsed:
                programs.extend(parsed)
                break

        return programs

    def parse_html(self, content, channel, day):
        soup = BeautifulSoup(content, "lxml")
        programs = []

        # Supondo que cada programa esteja em uma <tr> ou <div> com classe "program"
        rows = soup.select("tr.program, div.program-item, .programa")
        for row in rows:
            text = self.clean(row.get_text(" ", strip=True))
            if not text:
                continue

            # Extrai horário
            time_match = re.search(r"\b([01]?\d|2[0-3]):([0-5]\d)\b", text)
            if not time_match:
                continue

            start = self.make_datetime(day, time_match.group(0))
            if not start:
                continue

            title = re.sub(r"\b([01]?\d|2[0-3]):([0-5]\d)\b", "", text)
            title = self.clean(title)
            if not title:
                continue

            stop = start + timedelta(minutes=30)

            programs.append(SourceProgram(
                source=self.name,
                channel_name=channel.name,
                title=title,
                start=start,
                stop=stop,
                confidence=0.80,
            ))

        return programs

    @staticmethod
    def clean(value):
        return re.sub(r"\s+", " ", str(value or "")).strip()

    @classmethod
    def make_datetime(cls, day, time_str):
        parsed = cls.parse_time(time_str)
        if not parsed:
            return None
        hour, minute = parsed
        return datetime(day.year, day.month, day.day, hour, minute)

    @staticmethod
    def parse_time(value):
        match = re.search(r"\b([01]?\d|2[0-3]):([0-5]\d)\b", str(value))
        if not match:
            return None
        return int(match.group(1)), int(match.group(2))