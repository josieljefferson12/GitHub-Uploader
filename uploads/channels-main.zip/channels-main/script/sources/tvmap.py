#!/usr/bin/env python3

from __future__ import annotations

import re
from datetime import datetime, timedelta

from bs4 import BeautifulSoup

from .base import EPGSource, SourceProgram


class TVMapSource(EPGSource):

    name = "tvmap"

    priority = 2

    BASE_URL = (
        "https://tvmap.com.br/Programacao"
    )

    async def fetch(
        self,
        page,
        channel,
        day,
    ):

        aliases = self.aliases_for(
            channel
        )

        if not aliases:
            return []

        try:

            response = await page.goto(
                self.BASE_URL,
                wait_until="domcontentloaded",
                timeout=channel.page_timeout,
            )

        except Exception:

            return []

        if not response:
            return []

        if response.status >= 400:
            return []

        try:

            await page.wait_for_load_state(
                "networkidle",
                timeout=10000,
            )

        except Exception:

            pass

        await page.wait_for_timeout(
            channel.wait_after_load
        )

        html = await page.content()

        return self.parse(
            html,
            channel,
            day,
            aliases,
        )

    def parse(
        self,
        html,
        channel,
        day,
        aliases,
    ):

        soup = BeautifulSoup(
            html,
            "lxml",
        )

        aliases_normalized = {
            self.normalize(
                alias
            )
            for alias in aliases
        }

        programs = []

        # --------------------------------------------------
        # A página possui linhas/blocos por canal.
        # Procuramos os elementos que contenham os
        # aliases configurados.
        # --------------------------------------------------

        for element in soup.find_all(
            True
        ):

            text = self.clean(
                element.get_text(
                    " ",
                    strip=True,
                )
            )

            if not text:
                continue

            normalized = self.normalize(
                text
            )

            matched = False

            for alias in aliases_normalized:

                if alias and alias in normalized:

                    matched = True
                    break

            if not matched:
                continue

            # Evita capturar páginas inteiras.
            if len(text) > 12000:
                continue

            parsed = self.parse_line(
                text,
                channel,
                day,
            )

            if parsed:

                programs.extend(
                    parsed
                )

        return self.deduplicate(
            programs
        )

    def parse_line(
        self,
        text,
        channel,
        day,
    ):

        programs = []

        matches = list(
            re.finditer(
                r"\b([01]?\d|2[0-3]):([0-5]\d)\b",
                text,
            )
        )

        if not matches:
            return []

        for index, match in enumerate(
            matches
        ):

            hour = int(
                match.group(1)
            )

            minute = int(
                match.group(2)
            )

            start = datetime(
                day.year,
                day.month,
                day.day,
                hour,
                minute,
            )

            # O texto anterior ao horário geralmente
            # contém o título.
            before = text[
                :match.start()
            ]

            # Remove delimitadores e cabeçalho.
            before = re.sub(
                r"\|",
                " ",
                before,
            )

            before = self.clean(
                before
            )

            # Tenta obter somente o último título.
            if before:

                parts = re.split(
                    r"\s{2,}",
                    before,
                )

                title = (
                    parts[-1]
                    if parts
                    else before
                )

            else:

                title = ""

            # Quando não conseguimos identificar
            # o título, ignoramos.
            if not title:
                continue

            # Horário seguinte = stop.
            if index + 1 < len(matches):

                next_match = matches[
                    index + 1
                ]

                next_start = datetime(
                    day.year,
                    day.month,
                    day.day,
                    int(
                        next_match.group(1)
                    ),
                    int(
                        next_match.group(2)
                    ),
                )

                # Virada de dia.
                if next_start <= start:

                    next_start += timedelta(
                        days=1
                    )

                stop = next_start

            else:

                stop = (
                    start
                    + timedelta(
                        minutes=30
                    )
                )

            programs.append(
                SourceProgram(
                    source=self.name,
                    channel_name=channel.name,
                    title=title,
                    start=start,
                    stop=stop,
                    confidence=0.80,
                )
            )

        return programs

    @staticmethod
    def deduplicate(
        programs
    ):

        result = {}

        for program in programs:

            key = (
                program.start,
                TVMapSource.normalize(
                    program.title
                ),
            )

            result[key] = program

        return list(
            result.values()
        )

    @staticmethod
    def clean(
        value
    ):

        return re.sub(
            r"\s+",
            " ",
            str(value or ""),
        ).strip()

    @staticmethod
    def normalize(
        value
    ):

        import unicodedata

        value = str(
            value or ""
        ).strip()

        value = unicodedata.normalize(
            "NFKD",
            value,
        )

        value = "".join(
            char
            for char in value
            if not unicodedata.combining(
                char
            )
        )

        return value.lower()