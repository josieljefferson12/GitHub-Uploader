#!/usr/bin/env python3

from __future__ import annotations

import re

from bs4 import BeautifulSoup

from .base import EPGSource, SourceProgram


class MiTVSource(EPGSource):

    name = "mitv"

    priority = 1

    BASE_URL = (
        "https://mi.tv/br/canais/"
    )

    async def fetch(
        self,
        page,
        channel,
        day,
    ):

        aliases = self.aliases_for(
            channel
        )

        if not aliases:

            if not channel.slug:
                return []

            aliases = [
                channel.slug
            ]

        programs = []

        for slug in aliases:

            slug = str(
                slug
            ).strip()

            if not slug:
                continue

            url = (
                self.BASE_URL
                + slug
            )

            if day != channel.today:

                url += (
                    "/"
                    + day.isoformat()
                )

            try:

                response = await page.goto(
                    url,
                    wait_until="domcontentloaded",
                    timeout=channel.page_timeout,
                )

            except Exception:

                continue

            if not response:
                continue

            if response.status >= 400:
                continue

            try:

                await page.wait_for_load_state(
                    "networkidle",
                    timeout=10000,
                )

            except Exception:

                pass

            await page.wait_for_timeout(
                channel.wait_after_load
            )

            content = await page.content()

            parsed = self.parse_html(
                content,
                channel,
                day,
            )

            if parsed:

                programs.extend(
                    parsed
                )

                break

        return programs

    def parse_html(
        self,
        content,
        channel,
        day,
    ):

        soup = BeautifulSoup(
            content,
            "lxml",
        )

        programs = []

        # --------------------------------------------------
        # Elementos com atributos de horário
        # --------------------------------------------------

        for element in soup.find_all(
            True
        ):

            attrs = element.attrs

            if not attrs:
                continue

            text = self.clean(
                element.get_text(
                    " ",
                    strip=True,
                )
            )

            if not text:
                continue

            start_value = None
            stop_value = None

            for key, value in attrs.items():

                key = str(
                    key
                ).lower()

                value = self.clean(
                    value
                )

                if (
                    "start" in key
                    or "begin" in key
                ):

                    if self.parse_time(
                        value
                    ):

                        start_value = value

                if (
                    "stop" in key
                    or "end" in key
                ):

                    if self.parse_time(
                        value
                    ):

                        stop_value = value

            if not start_value:

                match = re.search(
                    r"\b(?:[01]?\d|2[0-3]):[0-5]\d\b",
                    text,
                )

                if match:

                    start_value = (
                        match.group(0)
                    )

            if not start_value:
                continue

            start = self.make_datetime(
                day,
                start_value,
            )

            if not start:
                continue

            stop = None

            if stop_value:

                stop = self.make_datetime(
                    day,
                    stop_value,
                )

            if not stop:

                from datetime import timedelta

                stop = (
                    start
                    + timedelta(
                        minutes=30
                    )
                )

            title = re.sub(
                r"\b(?:[01]?\d|2[0-3]):[0-5]\d\b",
                "",
                text,
            )

            title = self.clean(
                title
            )

            if not title:
                continue

            programs.append(
                SourceProgram(
                    source=self.name,
                    channel_name=channel.name,
                    title=title,
                    start=start,
                    stop=stop,
                    confidence=1.0,
                )
            )

        return programs

    @staticmethod
    def clean(
        value
    ):

        return re.sub(
            r"\s+",
            " ",
            str(value or ""),
        ).strip()

    @staticmethod
    def parse_time(
        value
    ):

        if not value:
            return None

        match = re.search(
            r"\b([01]?\d|2[0-3]):([0-5]\d)\b",
            str(value),
        )

        if not match:
            return None

        return (
            int(match.group(1)),
            int(match.group(2)),
        )

    @classmethod
    def make_datetime(
        cls,
        day,
        value,
    ):

        from datetime import datetime

        parsed = cls.parse_time(
            value
        )

        if not parsed:
            return None

        hour, minute = parsed

        return datetime(
            day.year,
            day.month,
            day.day,
            hour,
            minute,
        )