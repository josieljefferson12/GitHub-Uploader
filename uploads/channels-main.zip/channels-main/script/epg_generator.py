#!/usr/bin/env python3

"""
EPG mi.tv V2
============

Gerador multisource de EPG XMLTV.

Fontes:

1. mi.tv      - prioridade principal
2. TV Map     - fallback
3. Guia de TV - fallback

Saídas:

output/epg.xml
output/epg.xml.gz
output/playlist.m3u
output/epg_aliases.json

Python 3.11+
"""

from __future__ import annotations

import asyncio
import gzip
import html
import json
import logging
import os
import re
import sys
import time
import unicodedata
import xml.etree.ElementTree as ET

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

CONFIG_FILE = ROOT / "config" / "channels.json"

OUTPUT_DIR = ROOT / "output"

OUTPUT_XML = OUTPUT_DIR / "epg.xml"

OUTPUT_GZ = OUTPUT_DIR / "epg.xml.gz"

OUTPUT_M3U = OUTPUT_DIR / "playlist.m3u"

OUTPUT_ALIASES = OUTPUT_DIR / "epg_aliases.json"

DEBUG_DIR = ROOT / "debug_mitv"


# ============================================================
# EPG PUBLIC URL
# ============================================================

EPG_URL = (
    "https://raw.githubusercontent.com/"
    "josieljefferson/channels/"
    "main/output/epg.xml.gz"
)


# ============================================================
# ENV
# ============================================================

DAYS = int(
    os.getenv(
        "MITV_DAYS_AHEAD",
        "2",
    )
)

MIN_PROGRAMS = int(
    os.getenv(
        "MITV_MIN_PROGRAMS",
        "1",
    )
)

PAGE_TIMEOUT = int(
    os.getenv(
        "MITV_PAGE_TIMEOUT",
        "60000",
    )
)

WAIT_AFTER_LOAD = int(
    os.getenv(
        "MITV_WAIT",
        "5000",
    )
)


# ============================================================
# LOG
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format=(
        "%(asctime)s | "
        "%(levelname)s | "
        "%(message)s"
    ),
)

log = logging.getLogger(
    "epg-mitv-v2"
)


# ============================================================
# MODELS
# ============================================================

@dataclass
class Channel:

    id: str

    name: str

    slug: str

    logo: str = ""

    group: str = "TV"

    stream: str = ""

    aliases: list[str] = field(
        default_factory=list
    )

    epg_sources: dict[str, list[str]] = field(
        default_factory=dict
    )

    today: date = field(
        default_factory=date.today
    )

    page_timeout: int = PAGE_TIMEOUT

    wait_after_load: int = WAIT_AFTER_LOAD


@dataclass
class Program:

    channel_id: str

    title: str

    start: datetime

    stop: datetime

    description: str = ""

    category: str = ""

    source: str = ""

    confidence: float = 0.0


# ============================================================
# TEXT
# ============================================================

def clean_text(
    value: Any,
) -> str:

    if value is None:
        return ""

    value = html.unescape(
        str(value)
    )

    value = re.sub(
        r"\s+",
        " ",
        value,
    )

    return value.strip()


def normalize(
    value: str,
) -> str:

    value = clean_text(
        value
    )

    value = unicodedata.normalize(
        "NFKD",
        value,
    )

    value = "".join(
        char
        for char in value
        if not unicodedata.combining(
            char
        )
    )

    return value.lower()


def xml_escape(
    value: str,
) -> str:

    return html.escape(
        clean_text(value),
        quote=True,
    )


# ============================================================
# CONFIG
# ============================================================

def load_config():

    if not CONFIG_FILE.exists():

        raise RuntimeError(
            f"Arquivo não encontrado: "
            f"{CONFIG_FILE}"
        )

    with CONFIG_FILE.open(
        "r",
        encoding="utf-8",
    ) as file:

        data = json.load(
            file
        )

    if not isinstance(
        data,
        dict,
    ):

        raise RuntimeError(
            "Configuração inválida."
        )

    settings = data.get(
        "settings",
        {},
    )

    raw_sources = data.get(
        "sources",
        {},
    )

    raw_channels = data.get(
        "channels",
        [],
    )

    if not isinstance(
        raw_channels,
        list,
    ):

        raise RuntimeError(
            "'channels' deve ser uma lista."
        )

    sources = {}

    for name, value in raw_sources.items():

        if not isinstance(
            value,
            dict,
        ):
            continue

        if value.get(
            "enabled",
            True,
        ):

            sources[name] = value

    channels = []

    ids = set()

    for index, item in enumerate(
        raw_channels,
        start=1,
    ):

        if not isinstance(
            item,
            dict,
        ):

            raise RuntimeError(
                f"Canal {index} inválido."
            )

        channel_id = clean_text(
            item.get("id")
        )

        name = clean_text(
            item.get("name")
        )

        slug = clean_text(
            item.get("slug")
        )

        if not channel_id:

            raise RuntimeError(
                f"Canal {index}: "
                "id ausente."
            )

        if not name:

            raise RuntimeError(
                f"Canal {index}: "
                "name ausente."
            )

        if channel_id in ids:

            raise RuntimeError(
                f"ID duplicado: "
                f"{channel_id}"
            )

        ids.add(
            channel_id
        )

        aliases = item.get(
            "aliases",
            [],
        )

        if not isinstance(
            aliases,
            list,
        ):

            aliases = []

        aliases = [
            clean_text(alias)
            for alias in aliases
            if clean_text(alias)
        ]

        epg_sources = item.get(
            "epg_sources",
            {},
        )

        if not isinstance(
            epg_sources,
            dict,
        ):

            epg_sources = {}

        normalized_sources = {}

        for source, values in epg_sources.items():

            if not isinstance(
                values,
                list,
            ):

                continue

            normalized_sources[
                source
            ] = [
                clean_text(value)
                for value in values
                if clean_text(value)
            ]

        channels.append(
            Channel(
                id=channel_id,
                name=name,
                slug=slug,
                logo=clean_text(
                    item.get("logo")
                ),
                group=clean_text(
                    item.get(
                        "group",
                        "TV",
                    )
                ),
                stream=clean_text(
                    item.get("stream")
                ),
                aliases=aliases,
                epg_sources=normalized_sources,
            )
        )

    if not channels:

        raise RuntimeError(
            "Nenhum canal configurado."
        )

    return (
        settings,
        sources,
        channels,
    )


# ============================================================
# SOURCES
# ============================================================

def create_sources(
    enabled_sources,
):

    from sources import (
        MiTVSource,
        TVMapSource,
        GuiaDeTVSource,
    )

    available = {
        "mitv": MiTVSource(),
        "tvmap": TVMapSource(),
        "guiadetv": GuiaDeTVSource(),
    }

    result = []

    for name, config in enabled_sources.items():

        source = available.get(
            name
        )

        if not source:

            continue

        source.priority = int(
            config.get(
                "priority",
                999,
            )
        )

        result.append(
            source
        )

    result.sort(
        key=lambda item:
        item.priority
    )

    return result


# ============================================================
# BROWSER
# ============================================================

async def create_browser():

    try:

        from playwright.async_api import (
            async_playwright,
        )

    except ImportError:

        raise RuntimeError(
            "Playwright não instalado."
        )

    playwright = (
        await async_playwright()
        .start()
    )

    browser = await playwright.chromium.launch(
        headless=True,
        args=[
            "--no-sandbox",
            "--disable-setuid-sandbox",
            "--disable-dev-shm-usage",
            "--disable-gpu",
            "--no-zygote",
            "--disable-blink-features=AutomationControlled",
        ],
    )

    return (
        playwright,
        browser,
    )


# ============================================================
# SOURCE PROGRAM -> PROGRAM
# ============================================================

def convert_program(
    source_program,
    channel,
):

    stop = source_program.stop

    if not stop:

        stop = (
            source_program.start
            + timedelta(
                minutes=30
            )
        )

    return Program(
        channel_id=channel.id,
        title=clean_text(
            source_program.title
        ),
        start=source_program.start,
        stop=stop,
        description=clean_text(
            source_program.description
        ),
        category=clean_text(
            source_program.category
        ),
        source=source_program.source,
        confidence=float(
            source_program.confidence
        ),
    )


# ============================================================
# NORMALIZATION
# ============================================================

def normalize_programs(
    programs: list[Program],
):

    unique = {}

    for program in programs:

        title = clean_text(
            program.title
        )

        if not title:

            continue

        key = (
            program.channel_id,
            program.start,
            normalize(title),
        )

        current = unique.get(
            key
        )

        if current is None:

            unique[key] = program

        elif (
            program.confidence
            > current.confidence
        ):

            unique[key] = program

    result = list(
        unique.values()
    )

    result.sort(
        key=lambda item: (
            item.channel_id,
            item.start,
        )
    )

    # --------------------------------------------------------
    # Corrigir STOP pelo próximo START
    # --------------------------------------------------------

    grouped = {}

    for program in result:

        grouped.setdefault(
            program.channel_id,
            [],
        ).append(
            program
        )

    final = []

    for items in grouped.values():

        for index, program in enumerate(
            items
        ):

            if index + 1 < len(items):

                next_program = (
                    items[index + 1]
                )

                if (
                    next_program.start
                    > program.start
                ):

                    program.stop = (
                        next_program.start
                    )

            if (
                program.stop
                <= program.start
            ):

                program.stop = (
                    program.start
                    + timedelta(
                        minutes=30
                    )
                )

            final.append(
                program
            )

    return final


# ============================================================
# FETCH CHANNEL / SOURCE
# ============================================================

async def fetch_channel_day(
    page,
    channel,
    source,
    day,
):

    channel.today = date.today()

    log.info(
        "Fonte: %s | Canal: %s | Data: %s",
        source.name,
        channel.name,
        day,
    )

    try:

        source_programs = (
            await source.fetch(
                page,
                channel,
                day,
            )
        )

    except Exception as exc:

        log.warning(
            "Fonte %s falhou para %s: %s",
            source.name,
            channel.name,
            exc,
        )

        return []

    programs = []

    for item in source_programs:

        try:

            program = convert_program(
                item,
                channel,
            )

            programs.append(
                program
            )

        except Exception as exc:

            log.warning(
                "Programa inválido: %s",
                exc,
            )

    return normalize_programs(
        programs
    )


# ============================================================
# MULTISOURCE
# ============================================================

async def collect_channel_day(
    page,
    channel,
    day,
    sources,
):

    collected = []

    for source in sources:

        programs = (
            await fetch_channel_day(
                page,
                channel,
                source,
                day,
            )
        )

        if programs:

            log.info(
                "✅ %s | %s | %d programas",
                source.name,
                channel.name,
                len(programs),
            )

            collected.extend(
                programs
            )

        else:

            log.warning(
                "⚠️ %s sem programação: %s",
                source.name,
                channel.name,
            )

    return normalize_programs(
        collected
    )


# ============================================================
# XMLTV
# ============================================================

def xml_time(
    value: datetime,
) -> str:

    return value.strftime(
        "%Y%m%d%H%M%S -0300"
    )


def generate_xml(
    channels,
    programs,
):

    lines = []

    lines.append(
        '<?xml version="1.0" encoding="UTF-8"?>'
    )

    lines.append(
        '<tv generator-info-name="epg-mitv-v2" '
        'generator-info-url="https://mi.tv/">'
    )

    for channel in channels:

        lines.append(
            f'  <channel id="{xml_escape(channel.id)}">'
        )

        lines.append(
            f'    <display-name lang="pt">'
            f'{xml_escape(channel.name)}'
            f'</display-name>'
        )

        if channel.logo:

            lines.append(
                f'    <icon src="{xml_escape(channel.logo)}" />'
            )

        lines.append(
            "  </channel>"
        )

    for program in programs:

        lines.append(
            f'  <programme '
            f'channel="{xml_escape(program.channel_id)}" '
            f'start="{xml_time(program.start)}" '
            f'stop="{xml_time(program.stop)}">'
        )

        lines.append(
            f'    <title lang="pt">'
            f'{xml_escape(program.title)}'
            f'</title>'
        )

        if program.description:

            lines.append(
                f'    <desc lang="pt">'
                f'{xml_escape(program.description)}'
                f'</desc>'
            )

        if program.category:

            lines.append(
                f'    <category lang="pt">'
                f'{xml_escape(program.category)}'
                f'</category>'
            )

        lines.append(
            "  </programme>"
        )

    lines.append(
        "</tv>"
    )

    return (
        "\n".join(lines)
        + "\n"
    )


# ============================================================
# M3U COM EPG
# ============================================================

def generate_m3u(
    channels,
):

    # --------------------------------------------------------
    # Cabeçalho M3U.
    #
    # O url-tvg informa ao player onde encontrar o EPG.
    # --------------------------------------------------------

    lines = [
        f'#EXTM3U url-tvg="{EPG_URL}"'
    ]

    for channel in channels:

        if not channel.stream:

            continue

        attributes = [
            f'tvg-id="{xml_escape(channel.id)}"',
            f'tvg-name="{xml_escape(channel.name)}"',
        ]

        if channel.logo:

            attributes.append(
                f'tvg-logo="{xml_escape(channel.logo)}"'
            )

        attributes.append(
            f'group-title="{xml_escape(channel.group)}"'
        )

        # ----------------------------------------------------
        # Cada tvg-id deve ser exatamente igual ao:
        #
        # <channel id="...">
        #
        # existente no epg.xml
        # ----------------------------------------------------

        lines.append(
            "#EXTINF:-1 "
            + " ".join(attributes)
            + f",{channel.name}"
        )

        lines.append(
            channel.stream
        )

    return (
        "\n".join(lines)
        + "\n"
    )


# ============================================================
# ALIASES
# ============================================================

def generate_aliases(
    channels,
):

    result = {}

    for channel in channels:

        result[channel.id] = {
            "name": channel.name,
            "aliases": channel.aliases,
            "sources": channel.epg_sources,
        }

    return json.dumps(
        result,
        ensure_ascii=False,
        indent=2,
    ) + "\n"


# ============================================================
# VALIDATE
# ============================================================

def validate_programs(
    channels,
    programs,
):

    if not programs:

        raise RuntimeError(
            "Nenhum programa foi encontrado."
        )

    counts = {}

    for program in programs:

        counts[
            program.channel_id
        ] = (
            counts.get(
                program.channel_id,
                0,
            )
            + 1
        )

    valid_channels = 0

    for channel in channels:

        count = counts.get(
            channel.id,
            0,
        )

        log.info(
            "📺 %-30s %d programas",
            channel.name,
            count,
        )

        if count >= MIN_PROGRAMS:

            valid_channels += 1

    if valid_channels == 0:

        raise RuntimeError(
            "Nenhum canal possui "
            "programação válida."
        )

    log.info(
        "Canais com EPG: %d/%d",
        valid_channels,
        len(channels),
    )


# ============================================================
# WRITE ATOMIC
# ============================================================

def atomic_write(
    path,
    content,
):

    temporary = path.with_suffix(
        path.suffix
        + ".tmp"
    )

    temporary.write_text(
        content,
        encoding="utf-8",
    )

    temporary.replace(
        path
    )


# ============================================================
# MAIN
# ============================================================

async def async_main():

    started = time.time()

    log.info(
        "=" * 70
    )

    log.info(
        "📺 EPG MI.TV V2"
    )

    log.info(
        "=" * 70
    )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    settings, source_config, channels = (
        load_config()
    )

    sources = create_sources(
        source_config
    )

    if not sources:

        raise RuntimeError(
            "Nenhuma fonte EPG habilitada."
        )

    log.info(
        "Canais: %d",
        len(channels),
    )

    log.info(
        "Fontes: %s",
        ", ".join(
            source.name
            for source in sources
        ),
    )

    playwright = None
    browser = None

    all_programs = []

    try:

        playwright, browser = (
            await create_browser()
        )

        context = (
            await browser.new_context(
                locale="pt-BR",
                timezone_id=(
                    settings.get(
                        "timezone_id",
                        "America/Sao_Paulo",
                    )
                ),
                viewport={
                    "width": 1366,
                    "height": 900,
                },
                user_agent=(
                    "Mozilla/5.0 "
                    "(X11; Linux x86_64) "
                    "AppleWebKit/537.36 "
                    "(KHTML, like Gecko) "
                    "Chrome/131.0.0.0 "
                    "Safari/537.36"
                ),
            )
        )

        page = (
            await context.new_page()
        )

        # ----------------------------------------------------
        # Bloqueia recursos pesados.
        # ----------------------------------------------------

        async def route_handler(
            route,
        ):

            resource = (
                route.request.resource_type
            )

            if resource in {
                "image",
                "font",
                "media",
            }:

                await route.abort()

            else:

                await route.continue_()

        await page.route(
            "**/*",
            route_handler,
        )

        today = date.today()

        # ----------------------------------------------------
        # DAYS = número real de dias.
        #
        # DAYS=2:
        # hoje + amanhã
        # ----------------------------------------------------

        days = [
            today
            + timedelta(
                days=offset
            )
            for offset in range(
                DAYS
            )
        ]

        for channel in channels:

            channel_programs = []

            log.info("")
            log.info(
                "=" * 70
            )

            log.info(
                "📡 CANAL: %s",
                channel.name,
            )

            log.info(
                "=" * 70
            )

            for day in days:

                programs = (
                    await collect_channel_day(
                        page,
                        channel,
                        day,
                        sources,
                    )
                )

                channel_programs.extend(
                    programs
                )

            channel_programs = (
                normalize_programs(
                    channel_programs
                )
            )

            log.info(
                "TOTAL %s: %d programas",
                channel.name,
                len(channel_programs),
            )

            all_programs.extend(
                channel_programs
            )

        all_programs = (
            normalize_programs(
                all_programs
            )
        )

    finally:

        if browser:

            await browser.close()

        if playwright:

            await playwright.stop()

    # --------------------------------------------------------
    # VALIDAR ANTES DE PUBLICAR
    # --------------------------------------------------------

    validate_programs(
        channels,
        all_programs,
    )

    # --------------------------------------------------------
    # XML
    # --------------------------------------------------------

    xml = generate_xml(
        channels,
        all_programs,
    )

    root = ET.fromstring(
        xml
    )

    if root.tag != "tv":

        raise RuntimeError(
            "XML inválido."
        )

    if not root.findall(
        "programme"
    ):

        raise RuntimeError(
            "XML sem programas."
        )

    # --------------------------------------------------------
    # M3U COM EPG
    # --------------------------------------------------------

    m3u = generate_m3u(
        channels
    )

    # --------------------------------------------------------
    # ALIASES
    # --------------------------------------------------------

    aliases = generate_aliases(
        channels
    )

    # --------------------------------------------------------
    # GZIP
    # --------------------------------------------------------

    gzip_data = gzip.compress(
        xml.encode("utf-8"),
        compresslevel=9,
        mtime=0,
    )

    # --------------------------------------------------------
    # PUBLICAÇÃO ATÔMICA
    # --------------------------------------------------------

    atomic_write(
        OUTPUT_XML,
        xml,
    )

    atomic_write(
        OUTPUT_M3U,
        m3u,
    )

    atomic_write(
        OUTPUT_ALIASES,
        aliases,
    )

    temporary_gz = (
        OUTPUT_GZ.with_suffix(
            ".gz.tmp"
        )
    )

    temporary_gz.write_bytes(
        gzip_data
    )

    temporary_gz.replace(
        OUTPUT_GZ
    )

    # --------------------------------------------------------
    # RESUMO
    # --------------------------------------------------------

    log.info("")
    log.info(
        "=" * 70
    )

    log.info(
        "✅ EPG V2 GERADO"
    )

    log.info(
        "=" * 70
    )

    log.info(
        "Canais: %d",
        len(channels),
    )

    log.info(
        "Programas: %d",
        len(all_programs),
    )

    log.info(
        "XML: %s",
        OUTPUT_XML,
    )

    log.info(
        "GZIP: %s",
        OUTPUT_GZ,
    )

    log.info(
        "M3U: %s",
        OUTPUT_M3U,
    )

    log.info(
        "Aliases: %s",
        OUTPUT_ALIASES,
    )

    log.info(
        "EPG URL: %s",
        EPG_URL,
    )

    log.info(
        "Tempo: %.2f segundos",
        time.time() - started,
    )

    return 0


# ============================================================
# ENTRY POINT
# ============================================================

def main():

    try:

        return asyncio.run(
            async_main()
        )

    except KeyboardInterrupt:

        log.error(
            "Execução interrompida."
        )

        return 130

    except Exception as exc:

        log.exception(
            "❌ ERRO FATAL: %s",
            exc,
        )

        return 1


if __name__ == "__main__":

    sys.exit(
        main()
    )
